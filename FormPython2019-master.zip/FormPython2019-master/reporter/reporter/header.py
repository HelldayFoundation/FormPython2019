import os
import json
import datetime
from pathlib import Path


def create_header(authors_list, loc="Paris"):
    """Creates the header text.
    
    Parameters
    ----------
    authors_list: a list of dict
        each dictionnary should contain "firstname" and "lastname" keys
    loc : str, optional, default "Paris"
        The localistaion from where the report is emitted
    
    Returns
    -------
    header_text : str
        The header text
    
    """
    
    today = datetime.date.today()
    date_string = today.strftime(f'{loc}, le %d/%m/%Y')
    author_strings = [date_string, "### Authors", "\n"]
    
    
    for author in authors_list:
        firstname = author.get("firstname", "")
        lastname = author.get("lastname", "")
        if not lastname:
            print('No value for lastname')
        author_string = f'- {firstname} {lastname}'

        author_strings.append(author_string)
    return "\n".join(author_strings)

def header_from_json_file(path_to_json_file,loc="Paris"):
    """ Génère l'en-tête avec les informations d'auteurs depuis le fichier
    donné en paramètre """
    try:
        # s'il existe, on ouvre le fichier passé en argument
        with open(path_to_json_file,"r") as authors_file:
            authors = json.load(authors_file)
            return create_header(authors,loc)
    except FileNotFoundError:
        # si le fichier n'existe pas, on retourne une erreur formatée
        print("### {} : not found".format(path_to_json_file))
        return ""