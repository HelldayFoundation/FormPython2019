def greet():
    """ A realy minimal function
    """
    print("Hello World!")
